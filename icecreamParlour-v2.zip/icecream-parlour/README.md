# Ice Cream Parlour (React + Material UI + Vite)

## Run
```
npm install
npm run dev        # http://localhost:5173
npm run build      # production build in /dist
```

## 1. WhatsApp orders
Open `.env` and set your own number (country code + number, digits only):
```
VITE_WHATSAPP_NUMBER=919876543210
```
When a signed-in customer clicks "Place order on WhatsApp", WhatsApp Web (desktop) or the app (mobile)
opens with the full order text ready. The customer taps Send.

## 2. Enquiry emails (EmailJS - free, no backend)
1. Create an account at https://www.emailjs.com
2. Email Services -> Add service (Gmail) -> copy the **Service ID**
3. Email Templates -> Create template. Use these variables:
   - Subject: `New enquiry from {{from_name}}`
   - Body: `Name: {{from_name}}  Email: {{from_email}}  Message: {{message}}`
   - "To email": your shop email. "Reply-To": `{{reply_to}}`
   Copy the **Template ID**
4. Account -> General -> copy the **Public Key**
5. Put the three values in `.env`:
```
VITE_EMAILJS_SERVICE_ID=service_xxxx
VITE_EMAILJS_TEMPLATE_ID=template_xxxx
VITE_EMAILJS_PUBLIC_KEY=xxxx
```
6. Restart `npm run dev`. Until these are set, the Contact form opens the visitor's mail app instead.

## How the app works
- Add to bucket: any menu card; the bucket icon (top right) shows a badge and opens the bucket drawer.
- Ordering needs an account: Checkout is a protected route and redirects to Sign in, then returns to Checkout.
- Accounts, bucket and orders are stored in the browser (localStorage). This is a front-end-only demo;
  for real accounts shared across devices you would add a backend (e.g. Firebase or Node + database).

## Structure
```
src/
  config.js                 env values (WhatsApp number, EmailJS keys)
  context/AuthContext.jsx   register / login / logout
  context/CartContext.jsx   bucket state + "added" toast
  utils/whatsapp.js         builds the order message + wa.me link
  utils/storage.js          safe localStorage helpers
  components/               Navbar, CartDrawer, FlavorCard, ProtectedRoute, ...
  pages/                    Home, Menu, About, Gallery, Contact, SignIn, Checkout, Orders
```
