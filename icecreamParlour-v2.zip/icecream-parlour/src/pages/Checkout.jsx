import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Box, Container, Card, Typography, TextField, Button, Stack, ToggleButtonGroup, ToggleButton, Divider } from '@mui/material';
import WhatsAppIcon from '@mui/icons-material/WhatsApp';
import StorefrontIcon from '@mui/icons-material/Storefront';
import DeliveryDiningIcon from '@mui/icons-material/DeliveryDining';
import SmartImage from '../components/SmartImage';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { read, write } from '../utils/storage';
import { whatsappLink } from '../utils/whatsapp';

export default function Checkout() {
  const { items, total, clear, setQty } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();

  const [form, setForm] = useState({ name: user.name, phone: user.phone || '', type: 'pickup', address: '', notes: '' });
  const [errors, setErrors] = useState({});

  const change = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  if (items.length === 0) {
    return (
      <Container maxWidth="sm" sx={{ py: 12, textAlign: 'center' }}>
        <Typography variant="h4" sx={{ mb: 1 }}>Your bucket is empty</Typography>
        <Typography sx={{ color: 'text.secondary', mb: 3 }}>Add some items from the menu to place an order.</Typography>
        <Button component={Link} to="/menu" variant="contained" size="large">Browse menu</Button>
      </Container>
    );
  }

  const placeOrder = (e) => {
    e.preventDefault();
    const err = {};
    if (form.name.trim().length < 2) err.name = 'Enter your name';
    if (!/^[6-9]\d{9}$/.test(form.phone.replace(/\s|-/g, ''))) err.phone = 'Enter a valid 10-digit mobile number';
    if (form.type === 'delivery' && form.address.trim().length < 10) err.address = 'Enter your full delivery address';
    setErrors(err);
    if (Object.keys(err).length) return;

    const order = {
      id: 'ICP' + Date.now().toString().slice(-7),
      date: new Date().toISOString(),
      userEmail: user.email,
      items: items.map(({ id, name, price, qty }) => ({ id, name, price, qty })),
      total,
      customer: { ...form, name: form.name.trim(), phone: form.phone.replace(/\s|-/g, '') },
    };
    write('icp_orders', [order, ...read('icp_orders', [])]);

    // Open WhatsApp (WhatsApp Web on desktop, the app on mobile) with the order text pre-filled
    window.open(whatsappLink(order), '_blank', 'noopener');

    clear();
    navigate('/orders', { state: { placed: order.id } });
  };

  return (
    <Container maxWidth="lg" sx={{ py: { xs: 5, md: 8 } }}>
      <Typography variant="h3" sx={{ mb: 4, fontSize: { xs: '2rem', md: '2.6rem' } }}>Checkout</Typography>
      <Box sx={{ display: 'grid', gap: 4, gridTemplateColumns: { xs: '1fr', md: '1.3fr 1fr' }, alignItems: 'start' }}>
        <Card component="form" onSubmit={placeOrder} noValidate sx={{ p: { xs: 3, md: 4 } }}>
          <Typography variant="h5" sx={{ mb: 3 }}>Your details</Typography>
          <Stack spacing={2.5}>
            <TextField label="Full name" name="name" value={form.name} onChange={change} error={!!errors.name} helperText={errors.name} fullWidth />
            <TextField label="Mobile number" name="phone" value={form.phone} onChange={change} error={!!errors.phone} helperText={errors.phone} fullWidth />

            <ToggleButtonGroup
              exclusive fullWidth value={form.type} color="primary"
              onChange={(_, v) => v && setForm({ ...form, type: v })}
              sx={{ '& .MuiToggleButton-root': { textTransform: 'none', py: 1.2, gap: 1 } }}
            >
              <ToggleButton value="pickup"><StorefrontIcon fontSize="small" /> Pickup</ToggleButton>
              <ToggleButton value="delivery"><DeliveryDiningIcon fontSize="small" /> Delivery</ToggleButton>
            </ToggleButtonGroup>

            {form.type === 'delivery' && (
              <TextField label="Delivery address" name="address" value={form.address} onChange={change} error={!!errors.address} helperText={errors.address} multiline rows={3} fullWidth />
            )}
            <TextField label="Notes (optional)" name="notes" value={form.notes} onChange={change} multiline rows={2} fullWidth />

            <Button type="submit" variant="contained" size="large" startIcon={<WhatsAppIcon />}
              sx={{ bgcolor: '#1FA855', '&:hover': { bgcolor: '#188C46' } }}>
              Place order on WhatsApp
            </Button>
            <Typography sx={{ fontSize: 12.5, color: 'text.secondary', textAlign: 'center' }}>
              WhatsApp opens with your order ready to send. Tap Send to confirm it with the parlour.
            </Typography>
          </Stack>
        </Card>

        <Card sx={{ p: 3 }}>
          <Typography variant="h5" sx={{ mb: 2 }}>Order summary</Typography>
          <Stack spacing={2} divider={<Divider />}>
            {items.map((i) => (
              <Box key={i.id} sx={{ display: 'flex', gap: 2, alignItems: 'center' }}>
                <SmartImage src={i.img} alt={i.name} sx={{ width: 56, height: 56, borderRadius: 2, flexShrink: 0 }} />
                <Box sx={{ flex: 1 }}>
                  <Typography sx={{ fontWeight: 600, fontSize: 14 }}>{i.name}</Typography>
                  <Typography sx={{ fontSize: 13, color: 'text.secondary' }}>
                    ₹{i.price} × {i.qty}{' '}
                    <Box component="span" onClick={() => setQty(i.id, i.qty - 1)} sx={{ color: 'primary.main', cursor: 'pointer', ml: 1 }}>
                      {i.qty > 1 ? 'reduce' : 'remove'}
                    </Box>
                  </Typography>
                </Box>
                <Typography sx={{ fontWeight: 600 }}>₹{i.price * i.qty}</Typography>
              </Box>
            ))}
          </Stack>
          <Divider sx={{ my: 2 }} />
          <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
            <Typography variant="h6">Total</Typography>
            <Typography variant="h6" sx={{ color: 'primary.main' }}>₹{total}</Typography>
          </Box>
          <Typography sx={{ mt: 1, fontSize: 12.5, color: 'text.secondary' }}>Payment is taken at pickup or on delivery.</Typography>
        </Card>
      </Box>
    </Container>
  );
}
