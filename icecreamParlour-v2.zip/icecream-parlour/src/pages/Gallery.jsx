import { useState } from 'react';
import { Box, Container, Dialog, IconButton } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import SmartImage from '../components/SmartImage';
import SectionHeading from '../components/SectionHeading';
import { IMG } from '../data/images';

const photos = [
  { src: IMG.cones, alt: 'Ice cream cones', h: 300 },
  { src: IMG.sundae, alt: 'Ice cream sundae', h: 380 },
  { src: IMG.strawberry, alt: 'Strawberry ice cream', h: 260 },
  { src: IMG.scoops, alt: 'Scoops in cups', h: 340 },
  { src: IMG.chocolate, alt: 'Chocolate ice cream', h: 300 },
  { src: IMG.gelato, alt: 'Gelato', h: 380 },
  { src: IMG.pastel, alt: 'Pastel ice cream', h: 280 },
  { src: IMG.swirl, alt: 'Ice cream swirl', h: 340 },
  { src: IMG.vanilla, alt: 'Vanilla ice cream', h: 300 },
];

export default function Gallery() {
  const [active, setActive] = useState(null);
  return (
    <Container maxWidth="lg" sx={{ py: { xs: 7, md: 10 } }}>
      <SectionHeading eyebrow="Gallery" title="A taste of the parlour" subtitle="Scoops, sundaes and happy moments from our counter." />
      <Box sx={{ columnCount: { xs: 1, sm: 2, md: 3 }, columnGap: '20px' }}>
        {photos.map((p) => (
          <Box
            key={p.alt} onClick={() => setActive(p)}
            sx={{ mb: '20px', breakInside: 'avoid', borderRadius: 3, overflow: 'hidden', cursor: 'zoom-in', '&:hover img': { transform: 'scale(1.05)' } }}
          >
            <SmartImage src={p.src} alt={p.alt} sx={{ height: p.h, transition: 'transform .5s' }} />
          </Box>
        ))}
      </Box>

      <Dialog open={Boolean(active)} onClose={() => setActive(null)} maxWidth="md" fullWidth PaperProps={{ sx: { bgcolor: 'transparent', boxShadow: 'none' } }}>
        <IconButton onClick={() => setActive(null)} sx={{ position: 'absolute', right: 8, top: 8, bgcolor: 'rgba(0,0,0,0.5)', color: '#fff', zIndex: 1, '&:hover': { bgcolor: 'rgba(0,0,0,0.7)' } }} aria-label="Close">
          <CloseIcon />
        </IconButton>
        {active && <SmartImage src={active.src} alt={active.alt} sx={{ maxHeight: '85vh', borderRadius: 3 }} />}
      </Dialog>
    </Container>
  );
}
