import { Link, useLocation } from 'react-router-dom';
import { Box, Container, Card, Typography, Button, Chip, Stack, Alert, Divider } from '@mui/material';
import WhatsAppIcon from '@mui/icons-material/WhatsApp';
import { useAuth } from '../context/AuthContext';
import { read } from '../utils/storage';
import { whatsappLink } from '../utils/whatsapp';

export default function Orders() {
  const { user } = useAuth();
  const location = useLocation();
  const placed = location.state?.placed;
  const orders = read('icp_orders', []).filter((o) => o.userEmail === user.email);

  return (
    <Container maxWidth="md" sx={{ py: { xs: 5, md: 8 } }}>
      <Typography variant="h3" sx={{ mb: 1, fontSize: { xs: '2rem', md: '2.6rem' } }}>My orders</Typography>
      <Typography sx={{ color: 'text.secondary', mb: 4 }}>Hi {user.name.split(' ')[0]}, here are your orders placed from this device.</Typography>

      {placed && (
        <Alert severity="success" sx={{ mb: 3 }}>
          Order <b>{placed}</b> created. If WhatsApp did not open, use the “Send on WhatsApp” button below to share it with the parlour.
        </Alert>
      )}

      {orders.length === 0 ? (
        <Card sx={{ p: 5, textAlign: 'center' }}>
          <Typography variant="h6" sx={{ mb: 1 }}>No orders yet</Typography>
          <Button component={Link} to="/menu" variant="contained" sx={{ mt: 1 }}>Browse menu</Button>
        </Card>
      ) : (
        <Stack spacing={3}>
          {orders.map((o) => (
            <Card key={o.id} sx={{ p: 3 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 1, mb: 2 }}>
                <Box>
                  <Typography sx={{ fontWeight: 700 }}>Order {o.id}</Typography>
                  <Typography sx={{ fontSize: 13, color: 'text.secondary' }}>{new Date(o.date).toLocaleString('en-IN')}</Typography>
                </Box>
                <Chip label={o.customer.type === 'delivery' ? 'Delivery' : 'Pickup'} color="secondary" size="small" />
              </Box>
              <Stack spacing={0.8} divider={<Divider flexItem />}>
                {o.items.map((i) => (
                  <Box key={i.id} sx={{ display: 'flex', justifyContent: 'space-between', fontSize: 14, py: 0.5 }}>
                    <span>{i.name} × {i.qty}</span><span>₹{i.price * i.qty}</span>
                  </Box>
                ))}
              </Stack>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: 2, flexWrap: 'wrap', gap: 2 }}>
                <Typography variant="h6">Total ₹{o.total}</Typography>
                <Button href={whatsappLink(o)} target="_blank" rel="noopener" startIcon={<WhatsAppIcon />} variant="outlined" color="success">
                  Send on WhatsApp
                </Button>
              </Box>
            </Card>
          ))}
        </Stack>
      )}
    </Container>
  );
}
