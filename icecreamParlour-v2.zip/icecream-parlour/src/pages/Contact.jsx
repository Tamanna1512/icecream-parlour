import { useState } from 'react';
import emailjs from '@emailjs/browser';
import { useAuth } from '../context/AuthContext';
import { EMAILJS, emailConfigured, SHOP_EMAIL } from '../config';
import { Box, Container, Typography, TextField, Button, Card, Stack, Snackbar, Alert, Avatar } from '@mui/material';
import PlaceIcon from '@mui/icons-material/Place';
import PhoneIcon from '@mui/icons-material/Phone';
import EmailIcon from '@mui/icons-material/Email';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import SendIcon from '@mui/icons-material/Send';
import SectionHeading from '../components/SectionHeading';

const info = [
  { icon: <PlaceIcon />, title: 'Address', lines: ['24 Main Street, Market Road', 'Your City 400001'] },
  { icon: <PhoneIcon />, title: 'Phone', lines: ['+91 98765 43210'] },
  { icon: <EmailIcon />, title: 'Email', lines: ['hello@icecreamparlour.com'] },
  { icon: <AccessTimeIcon />, title: 'Hours', lines: ['Mon–Thu 11am–10pm', 'Fri–Sat 11am–11:30pm', 'Sun 10am–10pm'] },
];

export default function Contact() {
  const { user } = useAuth();
  const [form, setForm] = useState({ name: user?.name || '', email: user?.email || '', message: '' });
  const [errors, setErrors] = useState({});
  const [sent, setSent] = useState(false);
  const [sending, setSending] = useState(false);
  const [failed, setFailed] = useState('');

  const change = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    const err = {};
    if (!form.name.trim()) err.name = 'Please enter your name';
    if (!/^\S+@\S+\.\S+$/.test(form.email)) err.email = 'Enter a valid email address';
    if (form.message.trim().length < 10) err.message = 'Message should be at least 10 characters';
    setErrors(err);
    if (Object.keys(err).length) return;

    // Fallback if EmailJS keys are not set yet: open the visitor's mail app with the message filled in
    if (!emailConfigured) {
      const body = `Name: ${form.name}\nEmail: ${form.email}\n\n${form.message}`;
      window.location.href = `mailto:${SHOP_EMAIL}?subject=${encodeURIComponent('Enquiry from ' + form.name)}&body=${encodeURIComponent(body)}`;
      return;
    }
    setSending(true);
    try {
      await emailjs.send(
        EMAILJS.serviceId, EMAILJS.templateId,
        { from_name: form.name, from_email: form.email, reply_to: form.email, message: form.message, to_email: SHOP_EMAIL },
        { publicKey: EMAILJS.publicKey }
      );
      setSent(true);
      setForm({ name: user?.name || '', email: user?.email || '', message: '' });
    } catch (error) {
      setFailed('Sorry, your message could not be sent. Please try again or email us directly.');
    } finally {
      setSending(false);
    }
  };

  return (
    <Container maxWidth="lg" sx={{ py: { xs: 7, md: 10 } }}>
      <SectionHeading eyebrow="Get in touch" title="We would love to hear from you" subtitle="Party bookings, bulk orders or just a hello — send us a message." />
      <Box sx={{ display: 'grid', gap: 4, gridTemplateColumns: { xs: '1fr', md: '1fr 1.2fr' }, alignItems: 'start' }}>
        <Stack spacing={2}>
          {info.map((i) => (
            <Card key={i.title} sx={{ p: 2.5, display: 'flex', gap: 2 }}>
              <Avatar sx={{ bgcolor: 'rgba(194,65,12,0.1)', color: 'primary.main' }}>{i.icon}</Avatar>
              <Box>
                <Typography sx={{ fontWeight: 600 }}>{i.title}</Typography>
                {i.lines.map((l) => <Typography key={l} sx={{ color: 'text.secondary', fontSize: 14 }}>{l}</Typography>)}
              </Box>
            </Card>
          ))}
        </Stack>

        <Card component="form" onSubmit={submit} noValidate sx={{ p: { xs: 3, md: 4 } }}>
          <Typography variant="h5" sx={{ mb: 3 }}>Send a message</Typography>
          <Stack spacing={2.5}>
            <TextField label="Your name" name="name" value={form.name} onChange={change} error={!!errors.name} helperText={errors.name} fullWidth />
            <TextField label="Email" name="email" type="email" value={form.email} onChange={change} error={!!errors.email} helperText={errors.email} fullWidth />
            <TextField label="Message" name="message" value={form.message} onChange={change} error={!!errors.message} helperText={errors.message} multiline rows={5} fullWidth />
            <Button type="submit" variant="contained" size="large" endIcon={<SendIcon />} disabled={sending} sx={{ alignSelf: 'flex-start' }}>{sending ? 'Sending...' : 'Send message'}</Button>
          </Stack>
        </Card>
      </Box>

      <Snackbar open={Boolean(failed)} autoHideDuration={5000} onClose={() => setFailed('')} anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}>
        <Alert severity="error" variant="filled" onClose={() => setFailed('')}>{failed}</Alert>
      </Snackbar>
      <Snackbar open={sent} autoHideDuration={4000} onClose={() => setSent(false)} anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}>
        <Alert severity="success" variant="filled" onClose={() => setSent(false)}>Thanks! We will get back to you soon.</Alert>
      </Snackbar>
    </Container>
  );
}
