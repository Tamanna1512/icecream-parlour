import { Link } from 'react-router-dom';
import { Box, Container, Typography, Button, Stack, Card, Avatar, Rating } from '@mui/material';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import GrassIcon from '@mui/icons-material/Grass';
import LocalShippingIcon from '@mui/icons-material/LocalShipping';
import WorkspacePremiumIcon from '@mui/icons-material/WorkspacePremium';
import StarIcon from '@mui/icons-material/Star';
import SmartImage from '../components/SmartImage';
import SectionHeading from '../components/SectionHeading';
import FlavorCard from '../components/FlavorCard';
import { IMG } from '../data/images';
import { flavors } from '../data/menu';

const features = [
  { icon: <GrassIcon />, title: 'Real Ingredients', text: 'Fresh milk, ripe fruit and real vanilla. No artificial flavours, ever.' },
  { icon: <WorkspacePremiumIcon />, title: 'Made Every Morning', text: 'Every tub is churned in-house in small batches the same day you eat it.' },
  { icon: <LocalShippingIcon />, title: 'Delivered Cold', text: 'Order for parties or home and we deliver in insulated freezer boxes.' },
];

const reviews = [
  { name: 'Aarav Mehta', text: 'The dark chocolate is the best I have had in the city. Rich, not too sweet and perfectly smooth.', init: 'A' },
  { name: 'Priya Sharma', text: 'We celebrated my daughter\'s birthday here. The sundaes were huge and the staff were lovely.', init: 'P' },
  { name: 'Rohan Kapoor', text: 'Pistachio with sea salt is unreal. I come every weekend. Clean shop and quick service.', init: 'R' },
];

export default function Home() {
  return (
    <>
      {/* HERO */}
      <Box sx={{ bgcolor: 'custom.cream', overflow: 'hidden' }}>
        <Container maxWidth="lg" sx={{ py: { xs: 6, md: 10 } }}>
          <Box sx={{ display: 'grid', gap: { xs: 6, md: 8 }, alignItems: 'center', gridTemplateColumns: { xs: '1fr', md: '1.05fr 1fr' } }}>
            <Box>
              <Typography variant="overline" sx={{ color: 'primary.main' }}>Small-batch · Since 2012</Typography>
              <Typography variant="h1" sx={{ fontSize: { xs: '2.6rem', sm: '3.4rem', md: '4.2rem' }, mt: 1 }}>
                Ice cream made <Box component="span" sx={{ color: 'primary.main', fontStyle: 'italic' }}>slowly</Box>,<br />enjoyed in seconds.
              </Typography>
              <Typography sx={{ mt: 3, fontSize: '1.1rem', color: 'text.secondary', maxWidth: 480, lineHeight: 1.8 }}>
                Handcrafted scoops, sundaes and shakes from fresh milk, real fruit and the finest chocolate. Come in, pick a flavour and stay a while.
              </Typography>
              <Stack direction={{ xs: 'column', sm: 'row' }} spacing={2} sx={{ mt: 4 }}>
                <Button component={Link} to="/menu" variant="contained" size="large" endIcon={<ArrowForwardIcon />}>View Menu</Button>
                <Button component={Link} to="/contact" variant="outlined" size="large" color="inherit" sx={{ borderColor: 'divider' }}>Find Us</Button>
              </Stack>
              <Stack direction="row" spacing={5} sx={{ mt: 6 }}>
                {[['30+', 'Flavours'], ['12k+', 'Happy guests'], ['4.9', 'Avg. rating']].map(([n, l]) => (
                  <Box key={l}>
                    <Typography variant="h4" sx={{ color: 'text.primary' }}>{n}</Typography>
                    <Typography sx={{ fontSize: 13, color: 'text.secondary' }}>{l}</Typography>
                  </Box>
                ))}
              </Stack>
            </Box>

            <Box sx={{ position: 'relative' }}>
              <SmartImage
                src={IMG.hero} alt="Colourful ice cream scoops in waffle cones"
                sx={{ height: { xs: 340, sm: 460, md: 540 }, borderRadius: { xs: '24px', md: '220px 220px 24px 24px' }, boxShadow: '0 30px 60px rgba(58,42,34,0.2)' }}
              />
              <Card sx={{ position: 'absolute', bottom: { xs: -18, md: 36 }, left: { xs: 12, md: -36 }, p: 2, display: 'flex', alignItems: 'center', gap: 1.5 }}>
                <Avatar sx={{ bgcolor: 'secondary.main' }}><StarIcon /></Avatar>
                <Box>
                  <Typography sx={{ fontWeight: 600, fontSize: 14 }}>Rated 4.9 / 5</Typography>
                  <Typography sx={{ fontSize: 12, color: 'text.secondary' }}>by 2,400+ reviews</Typography>
                </Box>
              </Card>
            </Box>
          </Box>
        </Container>
      </Box>

      {/* FEATURES */}
      <Container maxWidth="lg" sx={{ py: { xs: 8, md: 11 } }}>
        <SectionHeading eyebrow="Why choose us" title="Quality you can taste" />
        <Box sx={{ display: 'grid', gap: 3, gridTemplateColumns: { xs: '1fr', md: 'repeat(3,1fr)' } }}>
          {features.map((f) => (
            <Card key={f.title} sx={{ p: 4, textAlign: 'center' }}>
              <Avatar sx={{ width: 60, height: 60, mx: 'auto', mb: 2, bgcolor: 'rgba(194,65,12,0.1)', color: 'primary.main' }}>{f.icon}</Avatar>
              <Typography variant="h6" sx={{ mb: 1 }}>{f.title}</Typography>
              <Typography sx={{ color: 'text.secondary', lineHeight: 1.8, fontSize: 15 }}>{f.text}</Typography>
            </Card>
          ))}
        </Box>
      </Container>

      {/* SIGNATURE FLAVOURS */}
      <Box sx={{ bgcolor: '#fff', py: { xs: 8, md: 11 } }}>
        <Container maxWidth="lg">
          <SectionHeading eyebrow="Our favourites" title="Signature flavours" subtitle="The scoops our regulars come back for, churned fresh every day." />
          <Box sx={{ display: 'grid', gap: 3, gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr', lg: 'repeat(4,1fr)' } }}>
            {flavors.map((f) => <FlavorCard key={f.id} item={f} />)}
          </Box>
          <Box sx={{ textAlign: 'center', mt: 6 }}>
            <Button component={Link} to="/menu" variant="outlined" size="large" endIcon={<ArrowForwardIcon />}>See the full menu</Button>
          </Box>
        </Container>
      </Box>

      {/* STORY TEASER */}
      <Container maxWidth="lg" sx={{ py: { xs: 8, md: 11 } }}>
        <Box sx={{ display: 'grid', gap: { xs: 5, md: 8 }, alignItems: 'center', gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' } }}>
          <SmartImage src={IMG.parlour} alt="Fresh gelato in the parlour" sx={{ height: { xs: 300, md: 440 }, borderRadius: 4 }} />
          <Box>
            <Typography variant="overline" sx={{ color: 'primary.main' }}>Our story</Typography>
            <Typography variant="h2" sx={{ fontSize: { xs: '2rem', md: '2.6rem' }, mt: 0.5, mb: 2 }}>A family recipe, made with patience</Typography>
            <Typography sx={{ color: 'text.secondary', lineHeight: 1.9, mb: 3 }}>
              What started as a small counter and one tub of vanilla has grown into a neighbourhood favourite. We still make everything by hand, still use the same trusted farms and still believe good ice cream cannot be rushed.
            </Typography>
            <Button component={Link} to="/about" variant="contained" endIcon={<ArrowForwardIcon />}>Read our story</Button>
          </Box>
        </Box>
      </Container>

      {/* TESTIMONIALS */}
      <Box sx={{ bgcolor: 'custom.cream', py: { xs: 8, md: 11 } }}>
        <Container maxWidth="lg">
          <SectionHeading eyebrow="Kind words" title="Loved by our guests" />
          <Box sx={{ display: 'grid', gap: 3, gridTemplateColumns: { xs: '1fr', md: 'repeat(3,1fr)' } }}>
            {reviews.map((r) => (
              <Card key={r.name} sx={{ p: 3.5 }}>
                <Rating value={5} readOnly size="small" sx={{ color: 'custom.caramel' }} />
                <Typography sx={{ my: 2, lineHeight: 1.8, color: 'text.secondary' }}>“{r.text}”</Typography>
                <Stack direction="row" spacing={1.5} alignItems="center">
                  <Avatar sx={{ bgcolor: 'primary.main' }}>{r.init}</Avatar>
                  <Typography sx={{ fontWeight: 600 }}>{r.name}</Typography>
                </Stack>
              </Card>
            ))}
          </Box>
        </Container>
      </Box>

      {/* CTA */}
      <Box sx={{ bgcolor: 'custom.choco', py: { xs: 8, md: 10 }, textAlign: 'center' }}>
        <Container maxWidth="md">
          <Typography variant="h2" sx={{ color: '#fff', fontSize: { xs: '2rem', md: '2.8rem' } }}>Craving something cold?</Typography>
          <Typography sx={{ color: 'rgba(255,255,255,0.75)', mt: 2, mb: 4 }}>Visit us today or call ahead for party orders and take-home boxes.</Typography>
          <Button component={Link} to="/contact" variant="contained" size="large" sx={{ bgcolor: 'custom.caramel', color: 'custom.choco', '&:hover': { bgcolor: '#E8B574' } }}>
            Get Directions
          </Button>
        </Container>
      </Box>
    </>
  );
}
