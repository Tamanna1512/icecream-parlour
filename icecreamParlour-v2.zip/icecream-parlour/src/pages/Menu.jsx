import { useState } from 'react';
import { Box, Container, Typography, Tabs, Tab } from '@mui/material';
import FlavorCard from '../components/FlavorCard';
import SectionHeading from '../components/SectionHeading';
import { categories, menuItems } from '../data/menu';

export default function Menu() {
  const [cat, setCat] = useState('All');
  const items = cat === 'All' ? menuItems : menuItems.filter((i) => i.cat === cat);

  return (
    <>
      <Box sx={{ bgcolor: 'custom.cream', py: { xs: 7, md: 9 }, textAlign: 'center' }}>
        <Container maxWidth="md">
          <SectionHeading eyebrow="Our menu" title="Scoops, sundaes & shakes" subtitle="Everything is made fresh in-house. Prices include all taxes." />
        </Container>
      </Box>

      <Container maxWidth="lg" sx={{ py: { xs: 5, md: 8 } }}>
        <Box sx={{ display: 'flex', justifyContent: 'center', mb: 6 }}>
          <Tabs
            value={cat} onChange={(_, v) => setCat(v)} variant="scrollable" scrollButtons="auto" allowScrollButtonsMobile
            TabIndicatorProps={{ style: { display: 'none' } }}
            sx={{ '& .MuiTab-root': { borderRadius: 999, minHeight: 42, mx: 0.5, border: '1px solid', borderColor: 'divider', color: 'text.primary' },
                  '& .Mui-selected': { bgcolor: 'primary.main', color: '#fff !important', borderColor: 'primary.main' } }}
          >
            {categories.map((c) => <Tab key={c} label={c} value={c} disableRipple />)}
          </Tabs>
        </Box>

        <Box sx={{ display: 'grid', gap: 3, gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr', md: 'repeat(3,1fr)' } }}>
          {items.map((item) => <FlavorCard key={item.id} item={item} />)}
        </Box>

        <Typography sx={{ textAlign: 'center', mt: 6, fontSize: 13, color: 'text.secondary' }}>
          Vegan and sugar-free options available on request. Please tell us about any allergies.
        </Typography>
      </Container>
    </>
  );
}
