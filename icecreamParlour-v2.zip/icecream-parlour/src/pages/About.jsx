import { Box, Container, Typography, Card, Avatar } from '@mui/material';
import SmartImage from '../components/SmartImage';
import SectionHeading from '../components/SectionHeading';
import { IMG } from '../data/images';

const timeline = [
  { year: '2012', title: 'The first tub', text: 'We opened a tiny counter with just six flavours and a hand-cranked churn.' },
  { year: '2016', title: 'Moving to Main Street', text: 'Our regulars outgrew the counter, so we opened the parlour you see today.' },
  { year: '2020', title: 'Going small-batch', text: 'We switched to local dairy and began churning fresh every single morning.' },
  { year: '2024', title: '30+ flavours', text: 'Today we serve over thirty flavours, from classics to seasonal specials.' },
];
const team = [
  { name: 'Meera Joshi', role: 'Founder & Head Churner', i: 'M' },
  { name: 'Karan Patel', role: 'Pastry & Cone Chef', i: 'K' },
  { name: 'Sana Iyer', role: 'Flavour Developer', i: 'S' },
];

export default function About() {
  return (
    <>
      <Box sx={{ bgcolor: 'custom.cream', py: { xs: 7, md: 9 } }}>
        <Container maxWidth="lg">
          <Box sx={{ display: 'grid', gap: { xs: 5, md: 8 }, alignItems: 'center', gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' } }}>
            <Box>
              <Typography variant="overline" sx={{ color: 'primary.main' }}>Our story</Typography>
              <Typography variant="h1" sx={{ fontSize: { xs: '2.4rem', md: '3.4rem' }, mt: 1, mb: 3 }}>Good things take time</Typography>
              <Typography sx={{ color: 'text.secondary', lineHeight: 1.9 }}>
                We believe ice cream should taste like what it is made from. That means fresh milk, real fruit, quality chocolate and the patience to do it properly. No shortcuts, no artificial colours, just honest flavour.
              </Typography>
            </Box>
            <SmartImage src={IMG.scoops} alt="Scoops of ice cream in cups" sx={{ height: { xs: 280, md: 400 }, borderRadius: 4 }} />
          </Box>
        </Container>
      </Box>

      <Container maxWidth="md" sx={{ py: { xs: 8, md: 11 } }}>
        <SectionHeading eyebrow="Journey" title="How we got here" />
        <Box sx={{ position: 'relative', pl: { xs: 4, md: 0 } }}>
          <Box sx={{ position: 'absolute', left: { xs: 11, md: '50%' }, top: 0, bottom: 0, width: 2, bgcolor: 'divider' }} />
          {timeline.map((t, idx) => (
            <Box key={t.year} sx={{ position: 'relative', display: 'flex', justifyContent: { md: idx % 2 ? 'flex-end' : 'flex-start' }, mb: 4 }}>
              <Box sx={{ position: 'absolute', left: { xs: -28, md: 'calc(50% - 7px)' }, top: 26, width: 16, height: 16, borderRadius: '50%', bgcolor: 'primary.main', border: '3px solid', borderColor: 'background.default' }} />
              <Card sx={{ p: 3, width: { xs: '100%', md: '46%' } }}>
                <Typography sx={{ color: 'primary.main', fontWeight: 700 }}>{t.year}</Typography>
                <Typography variant="h6" sx={{ my: 0.5 }}>{t.title}</Typography>
                <Typography sx={{ color: 'text.secondary', fontSize: 15, lineHeight: 1.8 }}>{t.text}</Typography>
              </Card>
            </Box>
          ))}
        </Box>
      </Container>

      <Box sx={{ bgcolor: '#fff', py: { xs: 8, md: 11 } }}>
        <Container maxWidth="lg">
          <SectionHeading eyebrow="The people" title="Meet the team" />
          <Box sx={{ display: 'grid', gap: 3, gridTemplateColumns: { xs: '1fr', sm: 'repeat(3,1fr)' } }}>
            {team.map((p) => (
              <Card key={p.name} sx={{ p: 4, textAlign: 'center' }}>
                <Avatar sx={{ width: 84, height: 84, mx: 'auto', mb: 2, bgcolor: 'secondary.main', fontSize: 32, fontFamily: 'Playfair Display' }}>{p.i}</Avatar>
                <Typography variant="h6">{p.name}</Typography>
                <Typography sx={{ color: 'text.secondary', fontSize: 14 }}>{p.role}</Typography>
              </Card>
            ))}
          </Box>
        </Container>
      </Box>
    </>
  );
}
