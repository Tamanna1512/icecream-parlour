import { useState } from 'react';
import { Navigate, useLocation, useNavigate } from 'react-router-dom';
import { Box, Container, Card, Typography, Tabs, Tab, TextField, Button, Stack, Alert, InputAdornment, IconButton } from '@mui/material';
import VisibilityIcon from '@mui/icons-material/Visibility';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
import { useAuth } from '../context/AuthContext';

export default function SignIn() {
  const { user, login, register } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const from = location.state?.from || '/';

  const [tab, setTab] = useState(0);
  const [form, setForm] = useState({ name: '', email: '', phone: '', password: '' });
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState('');
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);

  if (user) return <Navigate to={from} replace />;

  const change = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const validate = () => {
    const err = {};
    if (tab === 1 && form.name.trim().length < 2) err.name = 'Enter your full name';
    if (!/^\S+@\S+\.\S+$/.test(form.email)) err.email = 'Enter a valid email address';
    if (tab === 1 && !/^[6-9]\d{9}$/.test(form.phone.replace(/\s|-/g, ''))) err.phone = 'Enter a valid 10-digit mobile number';
    if (form.password.length < 6) err.password = 'Password must be at least 6 characters';
    setErrors(err);
    return Object.keys(err).length === 0;
  };

  const submit = async (e) => {
    e.preventDefault();
    setServerError('');
    if (!validate()) return;
    setBusy(true);
    try {
      if (tab === 0) await login(form);
      else await register({ ...form, phone: form.phone.replace(/\s|-/g, '') });
      navigate(from, { replace: true });
    } catch (err) {
      setServerError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Box sx={{ bgcolor: 'custom.cream', py: { xs: 6, md: 10 }, minHeight: '70vh' }}>
      <Container maxWidth="xs">
        <Card sx={{ p: { xs: 3, sm: 4 } }}>
          <Typography variant="h4" sx={{ textAlign: 'center', mb: 0.5 }}>{tab === 0 ? 'Welcome back' : 'Create account'}</Typography>
          <Typography sx={{ textAlign: 'center', color: 'text.secondary', mb: 3, fontSize: 14 }}>
            {location.state?.needLogin ? 'Please sign in to place your order.' : 'Sign in to order your favourite scoops.'}
          </Typography>

          <Tabs value={tab} onChange={(_, v) => { setTab(v); setErrors({}); setServerError(''); }} variant="fullWidth" sx={{ mb: 3 }}>
            <Tab label="Sign in" />
            <Tab label="Register" />
          </Tabs>

          {serverError && <Alert severity="error" sx={{ mb: 2 }}>{serverError}</Alert>}

          <Box component="form" onSubmit={submit} noValidate>
            <Stack spacing={2.5}>
              {tab === 1 && <TextField label="Full name" name="name" value={form.name} onChange={change} error={!!errors.name} helperText={errors.name} fullWidth />}
              <TextField label="Email" name="email" type="email" value={form.email} onChange={change} error={!!errors.email} helperText={errors.email} fullWidth />
              {tab === 1 && <TextField label="Mobile number" name="phone" value={form.phone} onChange={change} error={!!errors.phone} helperText={errors.phone} fullWidth />}
              <TextField
                label="Password" name="password" type={show ? 'text' : 'password'} value={form.password} onChange={change}
                error={!!errors.password} helperText={errors.password} fullWidth
                InputProps={{ endAdornment: (
                  <InputAdornment position="end">
                    <IconButton onClick={() => setShow(!show)} edge="end" aria-label="Toggle password">{show ? <VisibilityOffIcon /> : <VisibilityIcon />}</IconButton>
                  </InputAdornment>) }}
              />
              <Button type="submit" variant="contained" size="large" fullWidth disabled={busy}>
                {busy ? 'Please wait...' : tab === 0 ? 'Sign in' : 'Create account'}
              </Button>
            </Stack>
          </Box>
        </Card>
      </Container>
    </Box>
  );
}
