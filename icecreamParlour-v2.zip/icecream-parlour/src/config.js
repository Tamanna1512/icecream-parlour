export const WHATSAPP_NUMBER = (import.meta.env.VITE_WHATSAPP_NUMBER || '919876543210').replace(/\D/g, '');

export const EMAILJS = {
  serviceId: import.meta.env.VITE_EMAILJS_SERVICE_ID,
  templateId: import.meta.env.VITE_EMAILJS_TEMPLATE_ID,
  publicKey: import.meta.env.VITE_EMAILJS_PUBLIC_KEY,
};

export const emailConfigured = Boolean(EMAILJS.serviceId && EMAILJS.templateId && EMAILJS.publicKey);
export const SHOP_EMAIL = 'hello@icecreamparlour.com';
