import { useState } from 'react';
import { Box } from '@mui/material';
import IcecreamIcon from '@mui/icons-material/Icecream';

// Photo with lazy loading. If the link ever fails, a soft tinted block is shown instead of a broken icon.
export default function SmartImage({ src, alt, sx, ...rest }) {
  const [failed, setFailed] = useState(false);

  if (failed) {
    return (
      <Box
        role="img"
        aria-label={alt}
        sx={{
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          background: 'linear-gradient(135deg,#FFE8D2,#F7CBD2)', color: 'rgba(58,42,34,0.35)',
          ...sx,
        }}
      >
        <IcecreamIcon sx={{ fontSize: 56 }} />
      </Box>
    );
  }
  return (
    <Box
      component="img" src={src} alt={alt} loading="lazy"
      onError={() => setFailed(true)}
      sx={{ display: 'block', width: '100%', objectFit: 'cover', ...sx }}
      {...rest}
    />
  );
}
