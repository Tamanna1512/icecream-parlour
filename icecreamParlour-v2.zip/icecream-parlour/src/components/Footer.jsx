import { Link } from 'react-router-dom';
import { Box, Container, Typography, IconButton, Stack, Divider } from '@mui/material';
import IcecreamIcon from '@mui/icons-material/Icecream';
import InstagramIcon from '@mui/icons-material/Instagram';
import FacebookIcon from '@mui/icons-material/Facebook';
import XIcon from '@mui/icons-material/X';
import PlaceIcon from '@mui/icons-material/Place';
import PhoneIcon from '@mui/icons-material/Phone';
import EmailIcon from '@mui/icons-material/Email';

const linkSx = { color: 'rgba(255,255,255,0.7)', textDecoration: 'none', fontSize: 14, '&:hover': { color: '#fff' } };

export default function Footer() {
  return (
    <Box component="footer" sx={{ bgcolor: 'custom.choco', color: '#fff', pt: 8, pb: 3 }}>
      <Container maxWidth="lg">
        <Box sx={{ display: 'grid', gap: 5, gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr', md: '1.6fr 1fr 1fr 1.3fr' } }}>
          <Box>
            <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 2 }}>
              <IcecreamIcon sx={{ color: 'custom.caramel' }} />
              <Typography variant="h6">Ice Cream Parlour</Typography>
            </Stack>
            <Typography sx={{ color: 'rgba(255,255,255,0.7)', fontSize: 14, lineHeight: 1.8, maxWidth: 300 }}>
              Small-batch ice cream, made fresh every morning with real ingredients and nothing artificial.
            </Typography>
            <Stack direction="row" spacing={1} sx={{ mt: 2 }}>
              {[InstagramIcon, FacebookIcon, XIcon].map((Icon, i) => (
                <IconButton key={i} size="small" sx={{ color: '#fff', border: '1px solid rgba(255,255,255,0.25)', '&:hover': { bgcolor: 'primary.main' } }}>
                  <Icon fontSize="small" />
                </IconButton>
              ))}
            </Stack>
          </Box>

          <Box>
            <Typography variant="subtitle1" sx={{ fontFamily: 'Playfair Display', mb: 2 }}>Explore</Typography>
            <Stack spacing={1.2}>
              {[['Home', '/'], ['Menu', '/menu'], ['Our Story', '/about'], ['Gallery', '/gallery'], ['Contact', '/contact']].map(([t, to]) => (
                <Box key={to} component={Link} to={to} sx={linkSx}>{t}</Box>
              ))}
            </Stack>
          </Box>

          <Box>
            <Typography variant="subtitle1" sx={{ fontFamily: 'Playfair Display', mb: 2 }}>Opening Hours</Typography>
            <Stack spacing={1} sx={{ fontSize: 14, color: 'rgba(255,255,255,0.7)' }}>
              <span>Mon – Thu: 11am – 10pm</span>
              <span>Fri – Sat: 11am – 11:30pm</span>
              <span>Sunday: 10am – 10pm</span>
            </Stack>
          </Box>

          <Box>
            <Typography variant="subtitle1" sx={{ fontFamily: 'Playfair Display', mb: 2 }}>Visit Us</Typography>
            <Stack spacing={1.5} sx={{ fontSize: 14, color: 'rgba(255,255,255,0.7)' }}>
              <Stack direction="row" spacing={1}><PlaceIcon fontSize="small" /><span>24 Main Street, Market Road, Your City 400001</span></Stack>
              <Stack direction="row" spacing={1}><PhoneIcon fontSize="small" /><span>+91 98765 43210</span></Stack>
              <Stack direction="row" spacing={1}><EmailIcon fontSize="small" /><span>hello@icecreamparlour.com</span></Stack>
            </Stack>
          </Box>
        </Box>
        <Divider sx={{ my: 4, borderColor: 'rgba(255,255,255,0.12)' }} />
        <Typography sx={{ textAlign: 'center', fontSize: 13, color: 'rgba(255,255,255,0.55)' }}>
          © {new Date().getFullYear()} Ice Cream Parlour. All rights reserved.
        </Typography>
      </Container>
    </Box>
  );
}
