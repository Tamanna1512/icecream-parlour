import { Card, CardContent, Box, Typography, Chip, Button, IconButton } from '@mui/material';
import AddShoppingCartIcon from '@mui/icons-material/AddShoppingCart';
import AddIcon from '@mui/icons-material/Add';
import RemoveIcon from '@mui/icons-material/Remove';
import SmartImage from './SmartImage';
import { useCart } from '../context/CartContext';

export default function FlavorCard({ item }) {
  const { items, add, setQty } = useCart();
  const inCart = items.find((i) => i.id === item.id);

  return (
    <Card
      sx={{
        height: '100%', display: 'flex', flexDirection: 'column', overflow: 'hidden', transition: 'transform .3s, box-shadow .3s',
        '&:hover': { transform: 'translateY(-6px)', boxShadow: '0 16px 36px rgba(58,42,34,0.14)' },
        '&:hover img': { transform: 'scale(1.06)' },
      }}
    >
      <Box sx={{ position: 'relative', overflow: 'hidden', height: 220, flexShrink: 0 }}>
        <SmartImage src={item.img} alt={item.name} sx={{ height: 220, transition: 'transform .5s' }} />
        {item.tag && <Chip label={item.tag} size="small" color="primary" sx={{ position: 'absolute', top: 12, left: 12 }} />}
      </Box>
      <CardContent sx={{ p: 2.5, flex: 1, display: 'flex', flexDirection: 'column' }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', gap: 1 }}>
          <Typography variant="h6" sx={{ fontSize: '1.1rem' }}>{item.name}</Typography>
          <Typography sx={{ fontWeight: 600, color: 'primary.main', whiteSpace: 'nowrap' }}>₹{item.price}</Typography>
        </Box>
        <Typography sx={{ mt: 1, fontSize: 14, color: 'text.secondary', lineHeight: 1.7, flex: 1 }}>{item.desc}</Typography>

        <Box sx={{ mt: 2 }}>
          {inCart ? (
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', border: '1px solid', borderColor: 'primary.main', borderRadius: 999, px: 0.5 }}>
              <IconButton size="small" color="primary" onClick={() => setQty(item.id, inCart.qty - 1)} aria-label="Decrease"><RemoveIcon fontSize="small" /></IconButton>
              <Typography sx={{ fontWeight: 600, color: 'primary.main' }}>{inCart.qty} in bucket</Typography>
              <IconButton size="small" color="primary" onClick={() => setQty(item.id, inCart.qty + 1)} aria-label="Increase"><AddIcon fontSize="small" /></IconButton>
            </Box>
          ) : (
            <Button fullWidth variant="outlined" startIcon={<AddShoppingCartIcon />} onClick={() => add(item)}>Add to bucket</Button>
          )}
        </Box>
      </CardContent>
    </Card>
  );
}
