import { useState } from 'react';
import { NavLink, Link, useNavigate } from 'react-router-dom';
import {
  AppBar, Toolbar, Container, Box, Button, IconButton, Drawer, List, ListItemButton,
  ListItemText, Typography, useScrollTrigger, Badge, Menu, MenuItem, Avatar, Divider,
} from '@mui/material';
import ShoppingBagOutlinedIcon from '@mui/icons-material/ShoppingBagOutlined';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import MenuIcon from '@mui/icons-material/Menu';
import CloseIcon from '@mui/icons-material/Close';
import IcecreamIcon from '@mui/icons-material/Icecream';

const links = [
  { label: 'Home', to: '/' },
  { label: 'Menu', to: '/menu' },
  { label: 'Our Story', to: '/about' },
  { label: 'Gallery', to: '/gallery' },
  { label: 'Contact', to: '/contact' },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const [anchor, setAnchor] = useState(null);
  const { count, openDrawer } = useCart();
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const scrolled = useScrollTrigger({ disableHysteresis: true, threshold: 30 });

  return (
    <>
      <AppBar
        position="sticky" elevation={0} color="inherit"
        sx={{
          bgcolor: scrolled ? 'rgba(255,249,240,0.94)' : 'background.default',
          backdropFilter: 'blur(10px)',
          borderBottom: '1px solid', borderColor: scrolled ? 'divider' : 'transparent',
          transition: 'all .25s',
        }}
      >
        <Container maxWidth="lg">
          <Toolbar disableGutters sx={{ minHeight: { xs: 64, md: 78 }, justifyContent: 'space-between' }}>
            <Box component={Link} to="/" sx={{ display: 'flex', alignItems: 'center', gap: 1, textDecoration: 'none', color: 'text.primary' }}>
              <IcecreamIcon sx={{ color: 'primary.main', fontSize: 30 }} />
              <Typography variant="h6" sx={{ fontWeight: 700, letterSpacing: 0.3 }}>Ice Cream Parlour</Typography>
            </Box>

            <Box sx={{ display: { xs: 'none', md: 'flex' }, alignItems: 'center', gap: 0.5 }}>
              {links.map((l) => (
                <Button
                  key={l.to} component={NavLink} to={l.to} end={l.to === '/'}
                  sx={{
                    color: 'text.primary', px: 2, borderRadius: 2,
                    '&.active': { color: 'primary.main', fontWeight: 600, bgcolor: 'rgba(194,65,12,0.08)' },
                  }}
                >
                  {l.label}
                </Button>
              ))}
              <IconButton onClick={openDrawer} aria-label="Open bucket" sx={{ ml: 1 }}>
                <Badge badgeContent={count} color="primary"><ShoppingBagOutlinedIcon /></Badge>
              </IconButton>
              {user ? (
                <>
                  <Button onClick={(e) => setAnchor(e.currentTarget)} color="inherit" sx={{ ml: 1, gap: 1, px: 1.5 }}>
                    <Avatar sx={{ width: 28, height: 28, bgcolor: 'secondary.main', fontSize: 14 }}>{user.name[0].toUpperCase()}</Avatar>
                    {user.name.split(' ')[0]}
                  </Button>
                  <Menu anchorEl={anchor} open={Boolean(anchor)} onClose={() => setAnchor(null)}>
                    <MenuItem onClick={() => { setAnchor(null); navigate('/orders'); }}>My orders</MenuItem>
                    <Divider />
                    <MenuItem onClick={() => { setAnchor(null); logout(); navigate('/'); }}>Sign out</MenuItem>
                  </Menu>
                </>
              ) : (
                <Button component={Link} to="/signin" color="inherit" sx={{ ml: 1 }}>Sign in</Button>
              )}
              <Button component={Link} to="/menu" variant="contained" sx={{ ml: 1.5 }}>Order Now</Button>
            </Box>

            <Box sx={{ display: { xs: 'flex', md: 'none' }, alignItems: 'center' }}>
              <IconButton onClick={openDrawer} aria-label="Open bucket">
                <Badge badgeContent={count} color="primary"><ShoppingBagOutlinedIcon /></Badge>
              </IconButton>
              <IconButton onClick={() => setOpen(true)} aria-label="Open menu"><MenuIcon /></IconButton>
            </Box>
          </Toolbar>
        </Container>
      </AppBar>

      <Drawer anchor="right" open={open} onClose={() => setOpen(false)} PaperProps={{ sx: { width: 270, bgcolor: 'background.default' } }}>
        <Box sx={{ display: 'flex', justifyContent: 'flex-end', p: 1 }}>
          <IconButton onClick={() => setOpen(false)} aria-label="Close menu"><CloseIcon /></IconButton>
        </Box>
        <List sx={{ px: 1 }}>
          {links.map((l) => (
            <ListItemButton
              key={l.to} component={NavLink} to={l.to} end={l.to === '/'} onClick={() => setOpen(false)}
              sx={{ borderRadius: 2, '&.active': { bgcolor: 'rgba(194,65,12,0.1)', color: 'primary.main' } }}
            >
              <ListItemText primary={l.label} />
            </ListItemButton>
          ))}
        </List>
        <Box sx={{ p: 2, display: 'flex', flexDirection: 'column', gap: 1.5 }}>
          {user ? (
            <>
              <Typography sx={{ fontSize: 14, color: 'text.secondary' }}>Signed in as {user.name}</Typography>
              <Button fullWidth component={Link} to="/orders" variant="outlined" color="inherit" onClick={() => setOpen(false)}>My orders</Button>
              <Button fullWidth variant="outlined" color="inherit" onClick={() => { setOpen(false); logout(); navigate('/'); }}>Sign out</Button>
            </>
          ) : (
            <Button fullWidth component={Link} to="/signin" variant="outlined" color="inherit" onClick={() => setOpen(false)}>Sign in</Button>
          )}
          <Button fullWidth component={Link} to="/menu" variant="contained" onClick={() => setOpen(false)}>Order Now</Button>
        </Box>
      </Drawer>
    </>
  );
}
