import { useNavigate } from 'react-router-dom';
import { Drawer, Box, Typography, IconButton, Button, Stack, Divider } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import AddIcon from '@mui/icons-material/Add';
import RemoveIcon from '@mui/icons-material/Remove';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import ShoppingBagOutlinedIcon from '@mui/icons-material/ShoppingBagOutlined';
import SmartImage from './SmartImage';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';

export default function CartDrawer() {
  const { items, setQty, remove, total, count, drawerOpen, closeDrawer } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();

  const checkout = () => {
    closeDrawer();
    navigate(user ? '/checkout' : '/signin', user ? undefined : { state: { from: '/checkout', needLogin: true } });
  };

  return (
    <Drawer anchor="right" open={drawerOpen} onClose={closeDrawer} PaperProps={{ sx: { width: { xs: '100%', sm: 400 }, bgcolor: 'background.default' } }}>
      <Box sx={{ p: 2.5, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <Typography variant="h5">Your bucket {count > 0 && `(${count})`}</Typography>
        <IconButton onClick={closeDrawer} aria-label="Close bucket"><CloseIcon /></IconButton>
      </Box>
      <Divider />

      {items.length === 0 ? (
        <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center', p: 4, color: 'text.secondary' }}>
          <ShoppingBagOutlinedIcon sx={{ fontSize: 56, mb: 2, opacity: 0.5 }} />
          <Typography sx={{ fontWeight: 600, color: 'text.primary' }}>Your bucket is empty</Typography>
          <Typography sx={{ fontSize: 14, mb: 3 }}>Add some scoops from the menu.</Typography>
          <Button variant="contained" onClick={() => { closeDrawer(); navigate('/menu'); }}>Browse menu</Button>
        </Box>
      ) : (
        <>
          <Box sx={{ flex: 1, overflowY: 'auto', p: 2.5 }}>
            <Stack spacing={2.5}>
              {items.map((i) => (
                <Box key={i.id} sx={{ display: 'flex', gap: 2 }}>
                  <SmartImage src={i.img} alt={i.name} sx={{ width: 72, height: 72, borderRadius: 2, flexShrink: 0 }} />
                  <Box sx={{ flex: 1, minWidth: 0 }}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', gap: 1 }}>
                      <Typography sx={{ fontWeight: 600, fontSize: 15 }}>{i.name}</Typography>
                      <IconButton size="small" onClick={() => remove(i.id)} aria-label={`Remove ${i.name}`}><DeleteOutlineIcon fontSize="small" /></IconButton>
                    </Box>
                    <Typography sx={{ fontSize: 13, color: 'text.secondary' }}>₹{i.price} each</Typography>
                    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mt: 1 }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', border: '1px solid', borderColor: 'divider', borderRadius: 999 }}>
                        <IconButton size="small" onClick={() => setQty(i.id, i.qty - 1)} aria-label="Decrease"><RemoveIcon fontSize="small" /></IconButton>
                        <Typography sx={{ minWidth: 28, textAlign: 'center', fontWeight: 600 }}>{i.qty}</Typography>
                        <IconButton size="small" onClick={() => setQty(i.id, i.qty + 1)} aria-label="Increase"><AddIcon fontSize="small" /></IconButton>
                      </Box>
                      <Typography sx={{ fontWeight: 700, color: 'primary.main' }}>₹{i.price * i.qty}</Typography>
                    </Box>
                  </Box>
                </Box>
              ))}
            </Stack>
          </Box>
          <Divider />
          <Box sx={{ p: 2.5 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
              <Typography sx={{ fontWeight: 600 }}>Subtotal</Typography>
              <Typography variant="h6">₹{total}</Typography>
            </Box>
            <Button fullWidth variant="contained" size="large" onClick={checkout}>
              {user ? 'Proceed to checkout' : 'Sign in to order'}
            </Button>
          </Box>
        </>
      )}
    </Drawer>
  );
}
