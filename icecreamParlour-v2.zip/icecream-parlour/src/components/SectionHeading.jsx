import { Box, Typography } from '@mui/material';

export default function SectionHeading({ eyebrow, title, subtitle, align = 'center', light = false }) {
  return (
    <Box sx={{ textAlign: align, mb: { xs: 5, md: 7 }, maxWidth: 680, mx: align === 'center' ? 'auto' : 0 }}>
      {eyebrow && (
        <Typography variant="overline" sx={{ color: light ? 'custom.caramel' : 'primary.main' }}>
          {eyebrow}
        </Typography>
      )}
      <Typography variant="h2" sx={{ fontSize: { xs: '2rem', md: '2.8rem' }, mt: 0.5, color: light ? '#fff' : 'text.primary' }}>
        {title}
      </Typography>
      {subtitle && (
        <Typography sx={{ mt: 2, color: light ? 'rgba(255,255,255,0.75)' : 'text.secondary', lineHeight: 1.8 }}>
          {subtitle}
        </Typography>
      )}
    </Box>
  );
}
