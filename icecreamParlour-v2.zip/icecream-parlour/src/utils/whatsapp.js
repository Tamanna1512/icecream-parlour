import { WHATSAPP_NUMBER } from '../config';

export function buildOrderMessage(order) {
  const lines = order.items.map((i, n) => `${n + 1}. ${i.name} x ${i.qty} = ₹${i.price * i.qty}`);
  return [
    '*New Order - Ice Cream Parlour*',
    `Order ID: ${order.id}`,
    `Date: ${new Date(order.date).toLocaleString('en-IN')}`,
    '',
    `*Customer:* ${order.customer.name}`,
    `*Phone:* ${order.customer.phone}`,
    `*Type:* ${order.customer.type === 'delivery' ? 'Home delivery' : 'Pickup from parlour'}`,
    order.customer.type === 'delivery' ? `*Address:* ${order.customer.address}` : null,
    '',
    '*Items*',
    ...lines,
    '',
    `*Total: ₹${order.total}*`,
    order.customer.notes ? `Notes: ${order.customer.notes}` : null,
  ].filter((l) => l !== null).join('\n');
}

export function whatsappLink(order) {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(buildOrderMessage(order))}`;
}
