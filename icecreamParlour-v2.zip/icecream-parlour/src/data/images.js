// ALL images live here. Each one is a real JPG photo (Unsplash, free licence).
// To use your own photos: put them in /public/images and replace a URL with e.g. '/images/hero.jpg'.
const u = (id, w = 1200) =>
  `https://images.unsplash.com/photo-${id}?auto=format&fit=crop&fm=jpg&q=80&w=${w}`;

export const IMG = {
  hero: u('1563805042-7684c019e1cb', 1400),
  cones: u('1501443762994-82bd5dace89a'),
  scoops: u('1497034825429-c343d7c6a68f'),
  vanilla: u('1488900128323-21503983a07e'),
  strawberry: u('1560008581-09826d1de69e'),
  chocolate: u('1570197788417-0e82375c9371'),
  pastel: u('1505394033641-40c6ad1178d7'),
  sundae: u('1576506295286-5cda18df43e7'),
  parlour: u('1629385701021-fcd568a743e8'),
  cup: u('1567206563064-6f60f40a2b57'),
  gelato: u('1580915411954-282cb1b0d780'),
  swirl: u('1514849302-984523450cf4'),
};
