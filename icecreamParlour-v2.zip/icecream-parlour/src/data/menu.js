import { IMG } from './images';

export const categories = ['All', 'Scoops', 'Sundaes', 'Shakes', 'Cones & Cups'];

export const menuItems = [
  { id: 1, name: 'Madagascar Vanilla Bean', cat: 'Scoops', price: 120, img: IMG.vanilla, tag: 'Classic', desc: 'Slow-churned with real vanilla pods and fresh farm cream.' },
  { id: 2, name: 'Belgian Dark Chocolate', cat: 'Scoops', price: 140, img: IMG.chocolate, tag: 'Bestseller', desc: 'Deep, bittersweet and velvety, made with 70% cacao.' },
  { id: 3, name: 'Fresh Strawberry Cream', cat: 'Scoops', price: 130, img: IMG.strawberry, tag: 'Seasonal', desc: 'Ripe strawberries folded into sweet cream, no colouring.' },
  { id: 4, name: 'Pistachio & Sea Salt', cat: 'Scoops', price: 160, img: IMG.scoops, tag: 'Signature', desc: 'Roasted pistachios with a whisper of flaky sea salt.' },
  { id: 5, name: 'Hot Fudge Brownie Sundae', cat: 'Sundaes', price: 260, img: IMG.sundae, tag: 'Bestseller', desc: 'Warm brownie, three scoops, hot fudge and toasted nuts.' },
  { id: 6, name: 'Berry Cheesecake Sundae', cat: 'Sundaes', price: 280, img: IMG.cup, tag: 'New', desc: 'Cheesecake ice cream, berry compote and biscuit crumble.' },
  { id: 7, name: 'Caramel Crunch Sundae', cat: 'Sundaes', price: 250, img: IMG.swirl, desc: 'Salted caramel, praline crunch and whipped cream.' },
  { id: 8, name: 'Classic Chocolate Shake', cat: 'Shakes', price: 190, img: IMG.chocolate, desc: 'Thick, cold and made with two scoops of dark chocolate.' },
  { id: 9, name: 'Strawberry Milkshake', cat: 'Shakes', price: 180, img: IMG.strawberry, desc: 'Fresh strawberries blended with vanilla ice cream.' },
  { id: 10, name: 'Waffle Cone Double', cat: 'Cones & Cups', price: 150, img: IMG.cones, tag: 'Popular', desc: 'Two scoops of your choice in a fresh-baked waffle cone.' },
  { id: 11, name: 'Gelato Cup Trio', cat: 'Cones & Cups', price: 200, img: IMG.gelato, desc: 'Three small scoops: pick any flavours from the counter.' },
  { id: 12, name: 'Pastel Scoop Box', cat: 'Cones & Cups', price: 420, img: IMG.pastel, desc: 'A take-home box of six mini scoops, perfect for sharing.' },
];

export const flavors = [menuItems[1], menuItems[3], menuItems[2], menuItems[0]];
