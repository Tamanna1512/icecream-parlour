import { createContext, useContext, useState, useCallback } from 'react';
import { read, write, remove } from '../utils/storage';

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

async function hash(text) {
  if (window.crypto?.subtle) {
    const buf = await window.crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
    return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
  }
  return btoa(unescape(encodeURIComponent(text)));
}

// Front-end only demo auth: accounts live in this browser's localStorage.
export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => read('icp_session', null));

  const startSession = (u) => {
    const session = { id: u.id, name: u.name, email: u.email, phone: u.phone };
    setUser(session);
    write('icp_session', session);
  };

  const register = useCallback(async ({ name, email, phone, password }) => {
    const users = read('icp_users', []);
    const mail = email.trim().toLowerCase();
    if (users.some((u) => u.email === mail)) throw new Error('An account with this email already exists. Please sign in.');
    const u = { id: Date.now(), name: name.trim(), email: mail, phone: phone.trim(), pass: await hash(password) };
    write('icp_users', [...users, u]);
    startSession(u);
  }, []);

  const login = useCallback(async ({ email, password }) => {
    const users = read('icp_users', []);
    const u = users.find((x) => x.email === email.trim().toLowerCase());
    if (!u || u.pass !== (await hash(password))) throw new Error('Incorrect email or password.');
    startSession(u);
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    remove('icp_session');
  }, []);

  return <AuthContext.Provider value={{ user, register, login, logout }}>{children}</AuthContext.Provider>;
}
