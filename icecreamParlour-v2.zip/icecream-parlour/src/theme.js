import { createTheme } from '@mui/material/styles';

// Palette: warm vanilla cream, dark chocolate text, raspberry accent, pistachio secondary, caramel highlight
const theme = createTheme({
  palette: {
    primary: { main: '#C2410C', light: '#E5683A', dark: '#9A3412', contrastText: '#fff' }, // caramel-raspberry
    secondary: { main: '#6B8F71', light: '#8FB296', dark: '#4F6F55', contrastText: '#fff' }, // pistachio
    background: { default: '#FFF9F0', paper: '#FFFFFF' }, // vanilla
    text: { primary: '#3A2A22', secondary: '#7A675C' }, // chocolate
    divider: 'rgba(58,42,34,0.12)',
    custom: { cream: '#FFF1DC', choco: '#2E1F18', berry: '#B83A5E', caramel: '#D9A05B' },
  },
  shape: { borderRadius: 14 },
  typography: {
    fontFamily: '"Poppins", "Helvetica Neue", Arial, sans-serif',
    h1: { fontFamily: '"Playfair Display", serif', fontWeight: 700, lineHeight: 1.1 },
    h2: { fontFamily: '"Playfair Display", serif', fontWeight: 700, lineHeight: 1.15 },
    h3: { fontFamily: '"Playfair Display", serif', fontWeight: 600 },
    h4: { fontFamily: '"Playfair Display", serif', fontWeight: 600 },
    h5: { fontFamily: '"Playfair Display", serif', fontWeight: 600 },
    h6: { fontFamily: '"Playfair Display", serif', fontWeight: 600 },
    button: { textTransform: 'none', fontWeight: 500, letterSpacing: 0.3 },
    overline: { letterSpacing: 2.5, fontWeight: 600 },
  },
  components: {
    MuiButton: {
      defaultProps: { disableElevation: true },
      styleOverrides: {
        root: { borderRadius: 999, padding: '10px 26px' },
        sizeLarge: { padding: '13px 34px', fontSize: '1rem' },
      },
    },
    MuiCard: {
      styleOverrides: { root: { boxShadow: '0 6px 24px rgba(58,42,34,0.07)', border: '1px solid rgba(58,42,34,0.06)' } },
    },
    MuiChip: { styleOverrides: { root: { fontWeight: 500 } } },
  },
});

export default theme;
